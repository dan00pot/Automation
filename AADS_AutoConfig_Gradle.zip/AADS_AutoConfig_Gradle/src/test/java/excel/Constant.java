package excel;

public class Constant {
	public static final String PATH_TEST = "C:\\AADS\\AADS_Configuration\\TestSettings.xlsx";
	public static final String PATH_NETWORKDATA = "C:\\AADS\\AADS_Configuration\\NetworkData.xlsx";
	public static final String PATH_LABDATA = "C:\\AADS\\AADS_Configuration\\Lab.xlsx";
	public static final String PATH_TESTDATA = "C:\\AADS\\AADS_Configuration\\testData.xlsx";
	public static final String PATH_CONFIGSETTING = "C:\\AADS\\AADS_Configuration\\AADSConfigSettings.xlsx";
}
